package application.service;

import java.util.List;

import domain.rootaggregate.Order;
import domain.valueobj.OrderItem;

public interface OrderService {
	Order createOrder(String customerId) ;
    void removeItemFromOrder(Order order, OrderItem item);
	void addItemToOrder(Order order, String productId, int quantity);
	public List<Order> getOrdersByCustomer(String customerId);
}