package application.service;

import java.util.List;

import domain.entity.Product;

public interface ProductService {
	List<Product> getAllProducts();
	Product getProductById(String id);
	void saveProduct(Product product);
	void updateProduct(Product product);
	void deleteProduct(Product product);
}

