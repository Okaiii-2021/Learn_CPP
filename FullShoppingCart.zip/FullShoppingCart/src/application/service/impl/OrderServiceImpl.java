package application.service.impl;

import java.util.ArrayList;
import java.util.List;

import application.service.OrderService;
import domain.entity.Product;
import domain.factory.OrderFactory;
import domain.repository.OrderRepository;
import domain.repository.ProductRepository;
import domain.rootaggregate.Order;
import domain.service.InventoryService;
import domain.valueobj.OrderItem;
import infrastructure.OrderRepositoryFactory;
import infrastructure.ProductRepositoryFactory;

public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final InventoryService inventoryService;
    private final OrderFactory orderFactory = OrderFactory.INSTANCE;

    public OrderServiceImpl(InventoryService inventoryService) {
        this.orderRepository = OrderRepositoryFactory.getOrderRepository();
        this.productRepository = ProductRepositoryFactory.getProductRepository();
        this.inventoryService = inventoryService;
    }

    @Override
    public Order createOrder(String customerId) {
        Order order = orderFactory.createOrder(customerId);
        orderRepository.save(order);
        inventoryService.updateInventory(order);
        return order;
    }

    @Override
    public void addItemToOrder(Order order, String productId, int quantity) {
        Product product = productRepository.getProductById(productId);
        OrderItem orderItem = new OrderItem(product, quantity);
        order.addItem(orderItem);
        orderRepository.save(order);
        inventoryService.updateInventory(order);

    }

    @Override
    public void removeItemFromOrder(Order order, OrderItem item) {
        order.removeItem(item);
        orderRepository.save(order);
        inventoryService.updateInventory(order);

    }

	public OrderRepository getOrderRepository() {
		return orderRepository;
	}

	public ProductRepository getProductRepository() {
		return productRepository;
	}

	@Override
	public List<Order> getOrdersByCustomer(String customerId) {
	    List<Order> customerOrders = new ArrayList<>();
	    for (Order order : orderRepository.getAllOrders()) {
	        if (order.getCustomer().getId().equals(customerId)) {
	            customerOrders.add(order);
	        }
	    }
	    return customerOrders;
	}
}