package application.service.impl;

import java.util.List;

import application.service.ProductService;
import domain.entity.Product;
import domain.repository.ProductRepository;
import infrastructure.ProductRepositoryFactory;

//ProductServiceImpl.java
public class ProductServiceImpl implements ProductService {
	private final ProductRepository productRepository;

	public ProductServiceImpl() {
		this.productRepository = ProductRepositoryFactory.getProductRepository();
	}

	@Override
	public List<Product> getAllProducts() {
		return productRepository.getAllProducts();
	}

	@Override
	public Product getProductById(String id) {
		return productRepository.getProductById(id);
	}

	@Override
	public void saveProduct(Product product) {
		productRepository.saveProduct(product);
	}

	@Override
	public void updateProduct(Product product) {
		productRepository.updateProduct(product);
	}

	@Override
	public void deleteProduct(Product product) {
		productRepository.deleteProduct(product);
	}
}
