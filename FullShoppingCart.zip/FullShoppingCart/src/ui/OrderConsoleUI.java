package ui;

import java.util.List;
import java.util.Scanner;

import application.service.OrderService;
import application.service.ProductService;
import application.service.impl.OrderServiceImpl;
import application.service.impl.ProductServiceImpl;
import domain.entity.Product;
import domain.rootaggregate.Order;
import domain.service.InventoryService;
import domain.valueobj.OrderItem;

public class OrderConsoleUI {

    Scanner scanner = new Scanner(System.in);
    private final ProductService productService;
    private final OrderService orderService;

    public OrderConsoleUI() {
        this.orderService = new OrderServiceImpl(new InventoryService());
        this.productService = new ProductServiceImpl();
        
        productService.saveProduct(new Product("1", "Tao", 10.0));
        productService.saveProduct(new Product("2", "Cam", 20.0));
        productService.saveProduct(new Product("3", "Quit", 30.0));
    }

    public void run() {
        String input;

        System.out.println("Welcome to the Order Console!");
        System.out.println();

        do {
            System.out.println("Please choose an option:");
            System.out.println("1. View products");
            System.out.println("2. Create order");
            System.out.println("3. View order");
            System.out.println("4. Exit");
            input = scanner.nextLine();

            switch (input) {
                case "1":
                    viewProducts();
                    break;
                case "2":
                    createOrder();
                    break;
                case "3":
                	viewOrdersByCustomer();
                    break;                    
                case "4":
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid input, please try again.");
                    break;
            }

            System.out.println();
        } while (!input.equals("3"));
    }

    private void viewProducts() {
        System.out.println("Products:");
        for (Product product : productService.getAllProducts()) {
            System.out.printf("%s. %s - $%.2f%n", product.getId(), product.getName(), product.getPrice());
        }
    }

    public String getCustomerIdFromUser() {
        System.out.println("Enter customer ID: ");
        return scanner.nextLine();
    }
    
    public void viewOrdersByCustomer() {
        String customerId = getCustomerIdFromUser();
        List<Order> orders = orderService.getOrdersByCustomer(customerId);
        if (orders.isEmpty()) {
            System.out.println("No orders found for customer " + customerId);
        } else {
            System.out.println("Orders for customer " + customerId + ":");
            for (Order order : orders) {
                System.out.println(order);
            }
        }
    }
    private void createOrder() {
        String input;
        String customerId = getCustomerIdFromUser();
        Order order = orderService.createOrder(customerId);
        
        do {
            viewProducts();
            System.out.println("Please enter the ID of the product you want to order, or type 'done' to finish:");
            input = scanner.nextLine();

            if (!input.equals("done")) {
                try {
                    String productId = input;
                    Product product = productService.getProductById(productId);

                    if (product != null) {
                        System.out.printf("Product: %s - $%.2f%n", product.getName(), product.getPrice());

                        System.out.println("Please enter the quantity:");
                        int quantity = scanner.nextInt();
                        scanner.nextLine();

                        orderService.addItemToOrder(order, productId, quantity);
                    } else {
                        System.out.println("Invalid product ID, please try again.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input, please try again.");
                }
            }
        } while (!input.equals("done"));

        System.out.println("Order details:");
        for (OrderItem item : order.getItems()) {
            Product product = item.getProduct();
            int quantity = item.getQuantity();
            double totalPrice = item.getTotalPrice();
            System.out.printf("%s - %d x $%.2f = $%.2f%n", product.getName(), quantity, product.getPrice(), totalPrice);
        }
        System.out.printf("Total: $%.2f%n", order.getTotalAmount());
    }
    
    public static void main(String[] args) {
    	new OrderConsoleUI().run();
    }
}
