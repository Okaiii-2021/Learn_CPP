package domain.factory;
import domain.rootaggregate.Order;

public enum OrderFactory {
	INSTANCE;
    public Order createOrder(String customerId) {
        String orderNumber = generateOrderNumber();
        return new Order(orderNumber, customerId);
    }

    private String generateOrderNumber() {
        // generate a unique order number
        // implementation details omitted for brevity
        return "ORD-123456789";
    }
}





