package domain.rootaggregate;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import domain.internalaggregate.Customer;
import domain.valueobj.OrderItem;
import domain.valueobj.OrderStatus;


public class Order {
    private Long id;
    private Customer customer;
    private List<OrderItem> items;
    private double totalAmount;
    private LocalDateTime createdAt;
    private OrderStatus status;
    String orderNumber;

	public Order(String orderNumber, String customerId) {
		items = new ArrayList<>();
		this.orderNumber = orderNumber;
		customer = new Customer(customerId, orderNumber);
	}

	public Long getId() {
        return id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public List<OrderItem> getItems() {
        return items;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public void calculateTotalAmount() {
        double total = 0;
        for (OrderItem item : items) {
            total += item.getTotalPrice();
        }
        this.totalAmount = total;
    }

    public void addItem(OrderItem item) {
        items.add(item);
        calculateTotalAmount();
    }

    public void removeItem(OrderItem item) {
        items.remove(item);
        calculateTotalAmount();
    }

	public void cancel() {
		status = OrderStatus.CANCELLED;
		
	}


	public String toString() {
		StringBuilder s = new StringBuilder();
		s.append("customerID:" + customer.getId() + "\n");
		for (OrderItem item: items) {
			s.append(item.getProduct().getName() + ". quantity: " + item.getQuantity() + "\n");
		}
		return s.toString();
	}
}
