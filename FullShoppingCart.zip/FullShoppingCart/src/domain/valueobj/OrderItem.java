package domain.valueobj;

import domain.entity.Product;

public class OrderItem {
    private final Product product;
    private int quantity;

    public OrderItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

	public void increaseQuantity(int quantity2) {
		quantity += quantity2;
		
	}

	public void decreaseQuantity(int quantity2) {
		quantity -= quantity2;
		
		
	}

	public double getTotalPrice() {
		// TODO Auto-generated method stub
		return quantity * product.getPrice();
	}
}