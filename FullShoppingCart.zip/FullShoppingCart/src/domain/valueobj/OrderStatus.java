package domain.valueobj;

public enum OrderStatus {
    NEW,
    PAID,
    SHIPPED,
    CANCELLED
}