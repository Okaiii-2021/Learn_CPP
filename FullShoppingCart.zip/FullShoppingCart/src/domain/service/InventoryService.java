package domain.service;

import domain.rootaggregate.Order;

public class InventoryService {
    public void updateInventory(Order order) {
        // Update inventory logic here
        System.out.println("Inventory updated for order: " + order.getId());
    }
}