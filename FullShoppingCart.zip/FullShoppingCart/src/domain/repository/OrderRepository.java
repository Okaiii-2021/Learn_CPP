package domain.repository;

import java.util.List;

import domain.rootaggregate.Order;

public interface OrderRepository {
	    public Order getOrderById(Long id);
	    public List<Order> getAllOrders();
		public void save(Order order);
}
