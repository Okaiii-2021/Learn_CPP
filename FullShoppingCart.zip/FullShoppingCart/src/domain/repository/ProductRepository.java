package domain.repository;

import java.util.List;

import domain.entity.Product;

public interface ProductRepository {
    List<Product> getAllProducts();
    Product getProductById(String productId);
    void saveProduct(Product product);
    void updateProduct(Product product);
    void deleteProduct(Product product);
}