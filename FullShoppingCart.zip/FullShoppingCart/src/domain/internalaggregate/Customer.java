/*
In the context of an order management system, whether Customer is considered an internal aggregate or an entity depends on the design and requirements of the domain.
If Customer is treated as a standalone object with its own lifecycle and is not part of a larger cluster of related objects, 
then it can be modeled as an entity. In this case, it would have its own unique identity and attributes, and it can be directly accessed and modified.

However, if Customer is part of a larger cluster of related objects within an aggregate, such as an OrderAggregate 
that encapsulates both the Order and the Customer entities, then Customer would be considered an internal entity within that aggregate. 
In this case, the Customer entity would only be accessed and modified through the aggregate root, which is the Order entity.

The decision to model Customer as an internal aggregate entity or a standalone entity depends on the specific requirements and business rules of the domain. 
It's important to analyze the relationships and dependencies between objects and consider the transactional consistency and business invariants 
when determining the appropriate modeling approach.
 */
package domain.internalaggregate;

public class Customer {
    private String id;
    private String name;

    public Customer(String customerId, String name) {
        this.id = customerId;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

}
