package infrastructure;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import domain.repository.OrderRepository;
import domain.rootaggregate.Order;

public class InMemoryOrderRepository implements OrderRepository {
	private Map<Long, Order> orders = new HashMap<>();


    @Override
    public void save(Order order) {
        orders.put(order.getId(), order);
    }

    @Override
    public Order getOrderById(Long id) {
        return orders.get(id);
    }

    @Override
    public List<Order> getAllOrders() {
        return new ArrayList<>(orders.values());
    }
}
