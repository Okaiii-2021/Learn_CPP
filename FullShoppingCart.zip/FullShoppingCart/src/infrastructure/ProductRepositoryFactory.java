package infrastructure;

import domain.repository.ProductRepository;

public class ProductRepositoryFactory {
	private static ProductRepository productRepository = null;
	public static ProductRepository  getProductRepository() {
		if (productRepository == null) 
			productRepository = new InMemoryProductRepository();
		
		return productRepository ;
	
	}
}
