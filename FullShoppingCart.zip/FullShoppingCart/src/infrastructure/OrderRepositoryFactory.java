package infrastructure;

import domain.repository.OrderRepository;

public class OrderRepositoryFactory {
	private static OrderRepository orderRepository = null;
	public static OrderRepository  getOrderRepository() {
		if (orderRepository == null) 
			orderRepository = new InMemoryOrderRepository();
		
		return orderRepository;
	
	}
}
